import React, { useContext } from "react";
import { SenhaContext } from "../../../context/SenhaProvider";

import "./GeradorSenha.css"

function GeradorSenha() {
  const { gerarSenha } = useContext(SenhaContext);


  return (

    <div className="gerar-container" >
      <h1 className="h1">Sistema de Gestão de Senhas</h1>
      <div className="container-gerar">
      <div className="gerar-senha">
        <button className="gerar-button" onClick={() => gerarSenha("Normal")} style={{ marginRight: "10px" }}>
          Gerar Senha Normal
        </button>
        <button className="gerar-button" onClick={() => gerarSenha("Preferencial")}>
          Gerar Senha Preferencial
        </button>
      </div>
      </div>
    </div>
  );
}

export default GeradorSenha;
