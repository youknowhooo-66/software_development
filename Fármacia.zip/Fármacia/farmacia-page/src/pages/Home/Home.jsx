import './Home.css';
import { useState, useEffect } from 'react';


const Home = () => {

    const [visitas, setVisitas] = useState(0);
  
    useEffect(() => {

      const visitasSalvas = localStorage.getItem("visitas") || 0;
      const novasVisitas = parseInt(visitasSalvas) + 1;
  
      setVisitas(novasVisitas);
      localStorage.setItem("visitas", novasVisitas);
    }, []);

    return(

          <div className="container-home">
            <label className='label'>🎉 Você é o visitante número: {visitas}!</label>
            <div className="grid-item">
            <img
          src="https://media.giphy.com/media/ypqHf6pQ5kQEg/giphy.gif?cid=ecf05e47uyq7d4feygesahpepq3eu7m5ou9uuv6n2x8rthl2&ep=v1_gifs_search&rid=giphy.gif&ct=g"
          alt="Seja bem-vindo"
          className="gif-bemvindo"
        />
            <br/>
            <h1 className='h1'>Seja bem-vindo ao Farmácia!</h1>
            <p className='p'>Fique á vontade para conhecer os nossos serviços.</p>
          </div>
          </div>
    );
};

export default Home;
